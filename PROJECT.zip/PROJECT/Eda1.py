import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np

# Define function for EDA page
def show_eda():
    st.title('Exploratory Data Analysis (EDA)')

    # Load your dataset for EDA (replace this with your dataset loading logic)
    df = pd.read_csv('C:\\Users\\adity\\Downloads\\multiple-disease-prediction-streamlit-app-main\\multiple-disease-prediction-streamlit-app-main\\colab_files_to_train_models\\try_data.csv')

    # Display basic statistics and info about the dataset
    st.write('**Dataset Overview:**')
    st.write(df.head())

    st.write('**Summary Statistics:**')
    st.write(df.describe())

    # Display distribution of numeric features using charts
    st.write('**Distribution of Features:**')
    for col in df.columns:
        if df[col].dtype in [np.int64, np.float64]:  # Select numeric columns
            fig, ax = plt.subplots()
            sns.histplot(df[col], kde=True, ax=ax)
            ax.set_title(f'Distribution of {col}')  # Set title for the plot
            ax.set_xlabel(col)  # Set x-axis label
            ax.set_ylabel('Frequency')  # Set y-axis label
            st.pyplot(fig)

# Define function for algorithm-related graphs page
def show_algorithm_graphs():
    st.title('Algorithm Related Graphs')

    # Display specific graphs related to your algorithms (replace with your graph generation code)
    st.write('**Model Performance Metrics:**')
    # Example: Display a bar chart showing model performance metrics
    metrics = ['Accuracy', 'Precision', 'Recall', 'F1 Score']
    values = [0.85, 0.82, 0.78, 0.80]
    fig, ax = plt.subplots()
    ax.bar(metrics, values)
    ax.set_title('Model Performance Metrics')  # Set title for the plot
    ax.set_xlabel('Metrics')  # Set x-axis label
    ax.set_ylabel('Score')  # Set y-axis label
    st.pyplot(fig)

# Main function to handle navigation and page content
def main():
    # Sidebar navigation menu
    selected_page = st.selectbox('Navigation', ['Heart Disease Prediction', 'EDA', 'Algorithm Graphs'])

    # Display selected page content based on menu selection
    if selected_page == 'Heart Disease Prediction':
        st.title('Heart Disease Prediction')
        # Include the heart disease prediction code here (from your previous code snippet)
        # ...
    elif selected_page == 'EDA':
        show_eda()  # Show EDA page
    elif selected_page == 'Algorithm Graphs':
        show_algorithm_graphs()  # Show algorithm-related graphs page

if __name__ == '__main__':
    main()
